"""Atomic checkpoint export + reconcile with Drive.

Local SQLite is runtime state. Durable state is a JSON snapshot uploaded to
Drive folder DRIVE_APPDATA_FOLDER after every completed transfer.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Optional

from . import database as db
from .config import CHECKPOINTS_DIR, DRIVE_APPDATA_FOLDER
from .logging_config import get_logger
from .models import MediaItem
from .utils import atomic_write_bytes, now_iso

_log = get_logger("teledrive.checkpoint")

CHECKPOINT_PREFIX = "teledrive_checkpoint_"


def _snapshot_items() -> list[dict[str, Any]]:
    return [i.to_dict() for i in db.list_items(limit=10_000)]


def make_snapshot() -> dict[str, Any]:
    return {
        "generated": now_iso(),
        "counts": db.counts_by_state(),
        "items": _snapshot_items(),
    }


def persist_local() -> Path:
    CHECKPOINTS_DIR.mkdir(parents=True, exist_ok=True)
    snap = make_snapshot()
    path = CHECKPOINTS_DIR / f"{CHECKPOINT_PREFIX}{snap['generated'].replace(':', '-')}.json"
    atomic_write_bytes(path, json.dumps(snap, ensure_ascii=False, indent=2).encode("utf-8"))
    # prune older than 10
    files = sorted(CHECKPOINTS_DIR.glob(f"{CHECKPOINT_PREFIX}*.json"))
    for old in files[:-10]:
        try:
            old.unlink()
        except Exception:
            pass
    return path


def persist(drive=None) -> Optional[str]:
    """Best-effort checkpoint. Never used as a durability guarantee."""
    path = persist_local()
    if drive is None:
        return None
    try:
        folder_id = drive.ensure_folder(DRIVE_APPDATA_FOLDER)
        data = path.read_bytes()
        file_id = drive.upload_bytes(path.name, data, folder_id)
        return file_id
    except Exception as e:
        _log.warning("checkpoint drive upload failed: %s", e)
        return None


def persist_durable(drive) -> str:
    """Export a checkpoint that is PROVEN to be on Drive.

    Any failure raises :class:`CheckpointError`; it never returns ``None``
    silently, because the caller deletes temp files on success only.
    """
    from .errors import CheckpointError
    from .redaction import scan_for_secrets

    if drive is None:
        raise CheckpointError("durable checkpoint requires a Drive service")

    snap = make_snapshot()
    payload = json.dumps(snap, ensure_ascii=False, indent=2)
    hits = scan_for_secrets(payload)
    if hits:
        raise CheckpointError(f"checkpoint refused: {len(hits)} secret pattern(s) matched")

    CHECKPOINTS_DIR.mkdir(parents=True, exist_ok=True)
    path = CHECKPOINTS_DIR / f"{CHECKPOINT_PREFIX}{snap['generated'].replace(':', '-')}.json"
    atomic_write_bytes(path, payload.encode("utf-8"))
    for old in sorted(CHECKPOINTS_DIR.glob(f"{CHECKPOINT_PREFIX}*.json"))[:-10]:
        try:
            old.unlink()
        except Exception:
            pass

    try:
        folder_id = drive.ensure_folder(DRIVE_APPDATA_FOLDER)
        file_id = drive.upload_bytes(path.name, payload.encode("utf-8"), folder_id)
    except Exception as exc:
        raise CheckpointError(f"checkpoint upload failed: {exc}") from exc
    if not file_id:
        raise CheckpointError("checkpoint upload returned no file id")
    return file_id



def latest_local() -> Optional[Path]:
    if not CHECKPOINTS_DIR.exists():
        return None
    files = sorted(CHECKPOINTS_DIR.glob(f"{CHECKPOINT_PREFIX}*.json"))
    return files[-1] if files else None


class InvalidCheckpointError(Exception):
    """Raised when a checkpoint fails structural validation."""


def validate_snapshot(snap: Any) -> dict[str, Any]:
    """Reject malformed/corrupt checkpoints; redact secrets before return.

    Returns the snapshot unmodified on success. Never mutates persistent state.
    """
    from .errors import CheckpointError
    from .redaction import redact_mapping, scan_for_secrets

    if not isinstance(snap, dict):
        raise InvalidCheckpointError("checkpoint must be a JSON object")
    if "items" not in snap or not isinstance(snap["items"], list):
        raise InvalidCheckpointError("checkpoint missing 'items' list")
    for index, row in enumerate(snap["items"]):
        if not isinstance(row, dict):
            raise InvalidCheckpointError(f"checkpoint item {index} must be an object")
        item_id = str(row.get("id") or "")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", item_id):
            raise InvalidCheckpointError(f"checkpoint item {index} has an unsafe id")
    if "generated" not in snap:
        raise InvalidCheckpointError("checkpoint missing 'generated' timestamp")
    payload = json.dumps(snap, ensure_ascii=False)
    hits = scan_for_secrets(payload)
    if hits:
        raise CheckpointError(
            f"checkpoint refused: {len(hits)} secret pattern(s) matched"
        )
    # Re-parse after a defensive redaction pass so callers never re-emit secrets
    return json.loads(json.dumps(redact_mapping(snap), ensure_ascii=False))


def restore_latest_local() -> Optional[dict[str, Any]]:
    """Load and validate the newest local checkpoint (for unit tests / no-Drive)."""
    path = latest_local()
    if path is None:
        return None
    try:
        snap = json.loads(path.read_text(encoding="utf-8"))
        return validate_snapshot(snap)
    except (OSError, json.JSONDecodeError, InvalidCheckpointError) as e:
        _log.warning("local checkpoint unreadable, skipping: %s", e)
        return None


def restore_from_drive(drive) -> Optional[dict[str, Any]]:
    """Pull newest checkpoint from Drive, return parsed dict."""
    try:
        folder_id = drive.find_folder(DRIVE_APPDATA_FOLDER)
        if not folder_id:
            return None
        children = drive.list_children(folder_id)
        candidates = [c for c in children if c["name"].startswith(CHECKPOINT_PREFIX)]
        if not candidates:
            return None
        candidates.sort(key=lambda x: x.get("modifiedTime", ""), reverse=True)
        data = drive.download_bytes(candidates[0]["id"])
        return json.loads(data.decode("utf-8"))
    except Exception as e:
        _log.warning("checkpoint restore failed: %s", e)
        return None


def apply_snapshot(snap: dict[str, Any]) -> int:
    """Import checkpoint items into SQLite (if not present).

    The WHOLE snapshot is validated first: one unsafe row rejects the entire
    snapshot (fail-closed) instead of being silently skipped row-by-row.
    """
    snap = validate_snapshot(snap)
    n = 0
    for row in snap.get("items", []):
        try:
            item = MediaItem(**{k: v for k, v in row.items() if k in MediaItem.__dataclass_fields__})
            if db.get_item(item.id):
                continue
            db.upsert_item(item)
            n += 1
        except Exception:
            continue
    return n


def reconcile_with_drive(drive, queue=None) -> dict[str, int]:
    """Reconcile in-flight items against Drive.

    State is NEVER written here: every change goes through the INJECTED
    QueueManager, the only owner of transitions (Constitution Section 9).
    There is no module-level queue singleton (Phase C).
    """
    from .queue_manager import QueueManager

    q = queue if queue is not None else QueueManager()

    result = {"marked_uploaded": 0, "marked_needsretry": 0, "checked": 0}
    in_flight = ["Downloading", "Uploading", "Downloaded", "Verifying",
                 "UploadedPendingCheckpoint"]
    for item in db.items_in_states(in_flight):
        result["checked"] += 1

        try:
            existing = drive.find_by_source_key(item.source_key)
            found = (
                existing
                and item.size_bytes > 0
                and int(existing.get("size") or 0) == item.size_bytes
            )
            if found:
                moved = q.try_transition(
                    item.id, "Uploaded",
                    drive_file_id=existing["id"], upload_pct=100.0,
                )
                if moved is None and item.state == "Uploading":
                    q.try_transition(item.id, "Verifying")
                    q.try_transition(item.id, "UploadedPendingCheckpoint",
                                         drive_file_id=existing["id"])
                    moved = q.try_transition(item.id, "Uploaded", upload_pct=100.0)
                if moved is not None:
                    db.add_event(item.id, "reconcile", "found_on_drive")
                    result["marked_uploaded"] += 1
                    continue
            if q.try_transition(item.id, "NeedsRetry") is not None:
                db.add_event(item.id, "reconcile", "not_found_on_drive")
                result["marked_needsretry"] += 1

        except Exception as e:
            _log.warning("reconcile failed for %s: %s", item.id, e)
    return result
